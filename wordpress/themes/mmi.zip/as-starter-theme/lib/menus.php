<?php

/*
 *
 * Custom Menus
 *
 */

// Register your menus here.
register_nav_menu('main', __('Menu principal', 'skin'));
register_nav_menu('footer', __('Menu du pied de page', 'skin'));
