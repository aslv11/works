'use strict'; // Website wide scripts
// @Author Dummy Team

$(function () {
  $(window).ready(function () {
    console.log('Hi there!');
  });
});