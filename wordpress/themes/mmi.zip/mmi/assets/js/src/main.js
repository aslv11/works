'use strict'

// Website wide scripts
// @Author Dummy Team

$( () => {

  $(window).ready( () => {
    console.log('Hi there!')
  })

})
