<?php
    require(__DIR__.'/../shortcodes/my_shortcode/my_shortcode.php');
