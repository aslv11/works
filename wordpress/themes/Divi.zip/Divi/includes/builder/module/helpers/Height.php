<?php

/**
 * Helper class that provides necessary functions for managing height option
 *
 * Class ET_Builder_Module_Helper_Height
 */
class ET_Builder_Module_Helper_Height extends ET_Builder_Module_Helper_Sizing {

	public function get_raw_field() {
		return 'height';
	}
}
